#include <iostream>

using namespace std;

int main()
{
    int i;
    int j;
    int n;
    cout<<"please input a number n"<<endl;
    cin>>n;
    int C[n]={0};
    int open=0;
    int closed=0;
    for(i=1;i<=n;i++)
    {
        for(j=1;j<=n;j++)
        {
            if(j%i==0)
            C[j]=C[j]+1;
        }
    }
    cout<<endl;
    for(i=1;i<=n;i++)
    {
        cout<<C[i]<<endl;
    }
    cout<<endl;
    for(i=1;i<=n;i++)
    {
        if(C[i]%2==0)
            closed=closed+1;
        else
            open=open+1;
    }
    cout<<open<<endl;
    cout<<closed<<endl;
    return 0;
}
