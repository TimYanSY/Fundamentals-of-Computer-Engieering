//Shaoyang Yan platform:c++11
#include <iostream>
#include <vector>
#include <random>
#include <ctime>
using namespace std;
void populateVector(vector<int> &, double );
void printVector(vector<int> );
void insertionSort(vector<int> &);
int main() {
	cout << "please input an integer number n>1 " << endl;//input n
	int n;
	cin>>n;
	while(!(n>1))
	{
	cout<<"n is not qualified, please input n again"<<endl;
	cin>>n;
	}
	cout<<"n>1, n is qualified "<<"n is "<<n<<endl;
	cout<<"please input a real number m>1.0"<<endl;//input m
    double m;
	cin>>m;
	while(!(m>1.0))
	{
		cout<<"m is not qualified, please input m again"<<endl;
		cin>>m;
	}
	cout<<"m>1.0, m is qualified "<<"m is "<<m<<endl;
	vector<int> V1(n);
	populateVector(V1,m);
	cout<<"generate a n-random vector"<<endl;
	printVector(V1);
	cout<<"the generated vector after being sorted"<<endl;
	insertionSort(V1);
	printVector(V1);
	return 0;
}
void populateVector(vector<int> &A, double m)
{

    random_device rd;
    mt19937 gen(rd());
    uniform_int_distribution<> dis(-m, m);
    for (int i = 0; i < A.size(); i++)
    {
        int randomX = dis(gen);
        A[i]=randomX;
    }
}
void printVector(vector<int> A)
{
    for(int i=0;i<A.size();++i)
    {
        cout<<A[i]<<endl;
    }
}
void insertionSort(vector<int> &A)
{
    for(int j=1;j<A.size();j++)
    {
        int key=A[j];
        int i=j-1;
        while(i>=0&&A[i]>key)
        {
            A[i+1]=A[i];
            i=i-1;
        }
        A[i+1]=key;
    }
}

